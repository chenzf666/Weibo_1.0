Hoshino静态图片资源包

声明：本静态资源包内图片均来自互联网中可公开获取的资源，本资源包仅作整理搬运，著作权归原作者所有，切勿用于商业及非法用途！因本资源包而产生的利益纠纷及法律责任，由本资源包的直接使用者负责！


使用方法：解压本压缩包至任意位置，在HoshinoBot/config.py中配置RESOURCE_DIR路径
注意：路径应指向最外层文件夹，而非内层的img文件夹！
例如：
	您解压本资源包至C:/Users/Yuuki/Downloads/res/，则应配置
	RESOURCE_DIR = "C:/Users/Yuuki/Downloads/res/"
	文件夹priconne的路径应为"C:/Users/Yuuki/Downloads/res/img/priconne"

更新资源请使用本资源包中的爬虫img/priconne/spider.py，启动前请修改需要爬取的范围，仅爬取需要的部分即可。
rank表等资源由于月度更新，来源较杂，如需更新请于Hoshino的后花园群中向bot索要，您也可以搬运其他rank表，搬运时请注意保留原作者信息。
